import numpy as mp
import json
results = {}
tickers = ["AAPL", "GOOG", "ADBE", "SPOT", "AMZN", "V", "MSFT", "CSCO", "META", "CVX"]
for ticker in tickers:
    with open("/home/ubuntu/environment/Homework/HW_5/"+ ticker +".txt") as file:
        prices = [round(float(price.strip()), 2) for price in open("/home/ubuntu/environment/Homework/HW_5/"+ ticker+".txt").readlines()]
        def meanReversionStrategy(prices):
            i = 0
            buy = 0
            first_buy = 0
            total_profit = 0
            
            for price in prices:   
                current_price = price
                if i > 4:
                    avg_price = (prices[i-1] + prices[i-2] + prices[i-3] + prices[i-4] + prices[i-5]) / 5
                    avg_price = round(avg_price, 2)
                    if current_price < avg_price * .98 and buy == 0:
                        buy = current_price
                        if first_buy == 0:
                            first_buy += buy
                        print("Buying at:",buy)
                    elif current_price > avg_price * 1.02 and buy != 0:
                        print("Selling at:", current_price)
                        total_profit += current_price - buy
                        trade_profit = current_price - buy
                        total_profit = round(total_profit,2)
                        trade_profit = round(trade_profit, 2)
                        print("Trade profit:", trade_profit)
                        buy = 0
                i += 1
            final_profit_percentage = round(( total_profit / first_buy ) * 100, 2)
            return final_profit_percentage, total_profit
            
        MRS_percent, MRS_totprofit = meanReversionStrategy(prices)
        print("----------")
        print("Stock:", ticker) #added for clarity
        print("Total trade profit:", MRS_totprofit)
        print("% profit:", MRS_percent)
        
        print()
        
        def simpleMovingAverageStrategy(prices):
            i = 0
            buy = 0
            first_buy = 0
            total_profit = 0
            
            for price in prices:   
                current_price = price
                if i > 4:
                    avg_price = (prices[i-1] + prices[i-2] + prices[i-3] + prices[i-4] + prices[i-5]) / 5
                    avg_price = round(avg_price, 2)
                    if current_price > avg_price and buy == 0:
                        buy = current_price
                        if first_buy == 0:
                            first_buy += buy
                        print("Buying at:",buy)
                    elif current_price < avg_price and buy != 0:
                        print("Selling at:", current_price)
                        total_profit += current_price - buy
                        trade_profit = current_price - buy
                        total_profit = round(total_profit,2)
                        trade_profit = round(trade_profit, 2)
                        print("Trade profit:", trade_profit)
                        buy = 0
                i += 1
            final_profit_percentage = round((( total_profit / first_buy ) * 100),2)
            return final_profit_percentage, total_profit
        
        SMAS_percent, SMAS_totprofit = simpleMovingAverageStrategy(prices)
        print("----------")
        print("Stock:", ticker) #added for clarity
        print("Total trade profit:", SMAS_totprofit)
        print("% profit:", SMAS_percent)
        
        results[ticker + "SMovingAvg_totprofit"] = SMAS_totprofit
        results[ticker + "SMovingAvg_percent"] = SMAS_percent
        results[ticker + "MReversionStrat_totprofit"] = MRS_totprofit
        results[ticker + "MReversionStrat_percent"] = MRS_percent
        #print(results)
        
        print()
        print()
def saveResults(results):
    json.dump(results,open("/home/ubuntu/environment/Homework/HW_5/results.json","w"), indent = 2)
    
saveResults(results)
    