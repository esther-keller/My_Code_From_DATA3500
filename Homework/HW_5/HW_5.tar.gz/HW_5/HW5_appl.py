import numpy as np
import json
prices = [round(float(price.strip()), 2) for price in open("/home/ubuntu/environment/Homework/HW_5/APPL.txt").readlines()]
#print(prices)

def meanReversionStrategy(prices):
    i = 0
    buy = 0
    first_buy = 0
    total_profit = 0
    
    for price in prices:   
        current_price = price
        if i > 4:
            avg_price = (prices[i-1] + prices[i-2] + prices[i-3] + prices[i-4] + prices[i-5]) / 5
            avg_price = round(avg_price, 2)
            if current_price < avg_price * .98 and buy == 0:
                buy = current_price
                if first_buy == 0:
                    first_buy += buy
                print("Buying at:",buy)
            elif current_price > avg_price * 1.02 and buy != 0:
                print("Selling at:", current_price)
                total_profit += current_price - buy
                trade_profit = current_price - buy
                trade_profit = round(trade_profit, 2)
                print("Trade profit:", trade_profit)
                buy = 0
        i += 1
    final_profit_percentage = ( total_profit / first_buy ) * 100
    return final_profit_percentage, total_profit
    
MRS_percent, MRS_totprofit = meanReversionStrategy(prices)
print("----------")
print("Total trade profit:", round(MRS_totprofit,2))
print("% profit:", round(MRS_percent,2))

print()
print()

def simpleMovingAverageStrategy(prices):
    i = 0
    buy = 0
    first_buy = 0
    total_profit = 0
    
    for price in prices:   
        current_price = price
        if i > 4:
            avg_price = (prices[i-1] + prices[i-2] + prices[i-3] + prices[i-4] + prices[i-5]) / 5
            avg_price = round(avg_price, 2)
            if current_price > avg_price and buy == 0:
                buy = current_price
                if first_buy == 0:
                    first_buy += buy
                print("Buying at:",buy)
            elif current_price < avg_price and buy != 0:
                print("Selling at:", current_price)
                total_profit += current_price - buy
                trade_profit = current_price - buy
                trade_profit = round(trade_profit, 2)
                print("Trade profit:", trade_profit)
                buy = 0
        i += 1
    final_profit_percentage = ( total_profit / first_buy ) * 100
    return final_profit_percentage, total_profit

SMAS_percent, SMAS_totprofit = simpleMovingAverageStrategy(prices)
print("----------")
print("Total trade profit:", round(SMAS_totprofit,2))
print("% profit:", round(SMAS_percent,2))





# def saveResults(results):
#     json.dump(results,open("/home/ubuntu/environment/Homework/HW_5/results.json","w",indent=4))
# #initalize variables
# ticekers = ["APPL"]
# results = {}

# for ticker in tickers:
#     with open("/home/ubuntu/environment/Homework/HW_5/"+ ticker +".txt") as file:

results[ticker+"_Prices" = prices
results[ticker+"_MRS_Profit"] = MRS_totprofit
resuts[ticker+"_MRS_Percent"] = MRS_percent
results[ticker+"_SMAS_TotProfit"] = SMAS_totprofit
results[ticker+"_SMAS_Percent"] = SMAS_percent